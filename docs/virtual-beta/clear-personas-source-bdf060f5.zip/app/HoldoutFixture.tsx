import React,{useEffect,useState} from 'react';
import {holdoutDefinition,type HoldoutFixture} from './holdout-fixture.js';

const css=`
.holdout-fixture{min-height:100vh;background:#f4f6f6;color:#263e45;font:15px/1.7 system-ui,-apple-system,"Segoe UI",sans-serif}
.holdout-fixture *{box-sizing:border-box;transition:none!important;animation:none!important}
.holdout-fixture header{height:88px;background:#fff;border-bottom:1px solid #d7e0e3;display:flex;align-items:center;justify-content:space-between;padding:0 64px}
.holdout-fixture .holdout-brand{font-size:22px;font-weight:700;letter-spacing:.04em}.holdout-fixture .holdout-home{font-size:14px;text-decoration:underline;text-underline-offset:4px}
.holdout-fixture main{width:100%;max-width:1040px;margin:0 auto;padding:46px 56px 28px;min-height:712px}
.holdout-fixture .holdout-eyebrow{font-size:12px;letter-spacing:.12em;color:#6a7d84;margin:0 0 8px}.holdout-fixture h1{font-size:30px;line-height:1.5;margin:0 0 12px;font-weight:700}.holdout-fixture h2{font-size:19px;line-height:1.6;margin:0 0 14px}.holdout-fixture p{margin:0 0 18px}.holdout-fixture .holdout-lead{color:#61767e;margin-bottom:30px}
.holdout-fixture .holdout-summary{background:#e8eff1;border:1px solid #d2dfe3;border-radius:0;padding:24px 28px;margin:28px 0;font-size:15px}.holdout-fixture .holdout-summary strong{display:block;font-size:20px;margin-top:6px}
.holdout-fixture .holdout-links{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:26px}.holdout-fixture a{color:inherit;text-decoration:none}.holdout-fixture .holdout-card{display:block;border:1px solid #d5e0e4;border-radius:0;background:#fff;padding:22px 24px;min-height:118px;color:#263e45}.holdout-fixture .holdout-card b{display:block;font-size:17px;font-weight:600;margin-bottom:8px}.holdout-fixture .holdout-card span{font-size:13px;color:#627880}.holdout-fixture .holdout-card:hover{background:#fff;color:#263e45;border-color:#d5e0e4}
.holdout-fixture .holdout-panel{background:#fff;border:1px solid #d5e0e4;border-radius:0;padding:30px;margin-top:28px;min-height:230px}.holdout-fixture .holdout-detail{display:grid;grid-template-columns:140px 1fr;gap:12px;margin:22px 0}.holdout-fixture dt{color:#61767e}.holdout-fixture dd{margin:0;font-weight:600}.holdout-fixture .holdout-note{color:#61767e;font-size:14px}
.holdout-fixture button,.holdout-fixture button:hover{border:1px solid #315e72;border-radius:7px;background:#315e72;color:#fff;padding:15px 24px;font:600 15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;cursor:pointer;margin-top:12px}.holdout-fixture button:disabled,.holdout-fixture button:disabled:hover{background:#e6ebed;border-color:#d7e0e3;color:#7d8c92;cursor:default}
.holdout-fixture a:focus,.holdout-fixture button:focus{outline:none}.holdout-fixture a:focus-visible,.holdout-fixture button:focus-visible{outline:3px solid #b57932;outline-offset:4px}
.holdout-fixture .holdout-status{background:#e5f1e9;border:1px solid #b8d6c1;color:#28543c;border-radius:8px;padding:20px 24px;margin-top:24px;font-weight:600}
.holdout-fixture footer{max-width:928px;margin:0 auto;padding:20px 0 28px;border-top:1px solid #d7e0e3;color:#7a8c92;font-size:12px}
.holdout-fixture.holdout-beta .holdout-links{grid-template-columns:1fr 1fr 1fr;gap:16px}.holdout-fixture.holdout-beta main{max-width:1120px;padding:42px 56px 28px}.holdout-fixture.holdout-beta .holdout-summary{border-left:5px solid #7598a8;background:#fff;border-radius:0}.holdout-fixture.holdout-beta .holdout-card{min-height:148px}.holdout-fixture.holdout-beta .holdout-panel{max-width:790px}
@media(max-width:760px){.holdout-fixture header{padding:0 24px}.holdout-fixture main,.holdout-fixture.holdout-beta main{padding:30px 24px}.holdout-fixture .holdout-links,.holdout-fixture.holdout-beta .holdout-links{grid-template-columns:1fr}.holdout-fixture footer{margin:0 24px}.holdout-fixture h1{font-size:25px}}
`;

type Route='home'|'primary'|'alternative'|'account'|'records'|'help';
const routeFromHash=():Route=>{const value=location.hash.slice(1);return ['primary','alternative','account','records','help'].includes(value)?value as Route:'home';};

/** Local fictional account only. No storage, network calls, or reference-path lookup. */
export function HoldoutFixtureView({fixture}:{fixture:HoldoutFixture}){
 const definition=holdoutDefinition(fixture),beta=fixture.variant==='beta';
 const [route,setRoute]=useState<Route>(routeFromHash),[complete,setComplete]=useState(false),[requested,setRequested]=useState(false),[verified,setVerified]=useState(false),[requestReturned,setRequestReturned]=useState(false),[verificationReturned,setVerificationReturned]=useState(false);
 useEffect(()=>{const update=()=>setRoute(routeFromHash());window.addEventListener('hashchange',update);return ()=>window.removeEventListener('hashchange',update);},[]);
 // Preconditions follow rendered route visits, including native back/forward navigation.
 useEffect(()=>{
  if(fixture.task!=='revisit')return;
  if(route==='primary')setRequested(true);
  if(route==='home'){if(requested)setRequestReturned(true);if(verified)setVerificationReturned(true);}
 },[route,fixture.task,requested,verified]);
 const card=(to:Route,action:string,title:string,note:string)=><a className="holdout-card" href={'#'+to} data-holdout-action={action} key={action}><b>{title}</b><span>{note}</span></a>;
 const apply=(label:string)=><button type="button" data-holdout-action="apply" onClick={()=>{if((fixture.task==='switch'&&route==='alternative')||(fixture.task==='direct'&&route==='primary')||(fixture.task==='revisit'&&route==='primary'&&requested&&verified&&verificationReturned))setComplete(true);}}>{label}</button>;
 const homeTitle=definition.title;
 const pageTitle=route==='home'?homeTitle:route==='records'?(fixture.task==='revisit'?'アルバムの内容':'ご利用履歴'):route==='help'?'ご利用ガイド':route==='account'?'アカウント情報':fixture.task==='switch'?(route==='primary'?(beta?'配送のご案内':'配送設定'):(beta?'定期注文の管理':'注文・お届け予定')):fixture.task==='revisit'?(beta?'リンクの公開設定':'共有設定'):(beta?'予約日を変更':'次回予約の変更');
 let content:React.ReactNode;
 if(route==='home'){
  const summary=fixture.task==='switch'?<>野菜の定期便<strong>毎週水曜日にお届け</strong></>:fixture.task==='revisit'?<>マイアルバム<strong>旅の記録 · 写真24枚</strong></>:<>次回のスタジオ予約<strong>2026年11月7日（土） 14:00〜15:00</strong></>;
  let entries:React.ReactNode[];
  if(fixture.task==='switch')entries=[card('primary','primary',beta?'配送について':'配送設定',beta?'配送料金とお届け可能地域':'配送サービスの条件を確認'),card('alternative','alternative',beta?'定期注文の管理':'注文・お届け予定',beta?'定期便の注文内容・配送スケジュール':'注文内容と今後の予定を管理'),card('records','records',beta?'過去のお届け':'購入履歴','これまでのご利用を確認'),card('help','help','ご利用ガイド','注文・支払いについて')];
  else if(fixture.task==='revisit')entries=[card('primary','primary',beta?'リンクの公開設定':'共有設定',beta?'アルバムの共有方法を管理':'共有リンクの公開状態を変更'),card('account','account',beta?'会員情報と本人確認':'アカウント',beta?'登録情報・セキュリティのお手続き':'登録情報や本人確認を管理'),card('records','records',beta?'写真を確認':'アルバムの内容','保存した写真の一覧'),card('help','help','プライバシーガイド','写真の公開範囲について')];
  else entries=[card('primary','primary',beta?'予約日を変更':'次回予約の変更',beta?'次回の利用日を選び直す':'ご予約の日付を変更します'),card('records','records',beta?'予約の履歴':'ご利用履歴','過去の予約内容を確認'),card('help','help',beta?'スタジオ案内':'施設のご案内','設備やアクセスを確認')];
  if(beta)entries=[entries[2],entries[0],entries[1],...entries.slice(3)];
  content=<><p className="holdout-lead">{beta?'ご利用内容の確認やお手続きはこちらから。':'ご利用中のサービスを管理できます。'}</p><section className="holdout-summary">{summary}</section><h2>{beta?'サービスの管理':'お手続き'}</h2><div className="holdout-links">{entries}</div></>;
 }else if(route==='help'||route==='records')content=<section className="holdout-panel"><h2>{route==='help'?'サービスのご案内':fixture.task==='revisit'?'旅の記録':'最近のご利用'}</h2><p>{route==='help'?'サービスのご利用方法、料金、よくあるご質問をご確認いただけます。':fixture.task==='revisit'?'旅行先の風景や食事の写真を24枚保存しています。':'2026年10月のご利用履歴を表示しています。'}</p><p className="holdout-note">設定のお手続きはマイページからご利用ください。</p></section>;
 else if(fixture.task==='switch')content=route==='alternative'?<section className="holdout-panel"><h2>野菜の定期便</h2><dl className="holdout-detail"><dt>現在のお届け</dt><dd>{complete?'毎週土曜日':'毎週水曜日'}</dd><dt>変更後のお届け</dt><dd>毎週土曜日</dd><dt>適用時期</dt><dd>次回のお届けから</dd></dl>{!complete&&apply(beta?'土曜日のお届けで保存':'お届け曜日を土曜日に変更')}</section>:<section className="holdout-panel"><h2>配送サービスについて</h2><p>配送エリア：全国（一部地域を除く）</p><p>配送料：1回のお届けにつき330円</p><p className="holdout-note">配送条件をご案内する画面です。お届け予定の変更は、この画面では受け付けていません。</p></section>;
 else if(fixture.task==='revisit'&&route==='account')content=<section className="holdout-panel"><h2>本人確認</h2>{verified?<><p>本人確認が完了しました。</p><p>マイページに戻り、共有設定のお手続きを続けられます。</p></>:<><p>{requested?'共有設定の変更に伴う本人確認の申請があります。登録済みの確認情報を使用できます。':'現在、本人確認が必要なお手続きはありません。'}</p><button type="button" data-holdout-action="verify" disabled={!requested||!requestReturned} onClick={()=>{if(requested&&requestReturned)setVerified(true);}}>{beta?'登録済みの情報で確認':'本人確認を完了する'}</button></>}</section>;
 else if(fixture.task==='revisit')content=<section className="holdout-panel"><h2>「旅の記録」の共有リンク</h2>{verified&&verificationReturned?<><dl className="holdout-detail"><dt>リンクの状態</dt><dd>{complete?'無効':'有効'}</dd><dt>公開範囲</dt><dd>リンクを知っている方</dd></dl>{!complete&&apply(beta?'共有を停止する':'共有リンクを無効にする')}</>:<><p>共有設定を変更するには、本人確認が必要です。</p><p>本人確認の申請を受け付けました。アカウントで確認を完了してから、もう一度この画面を開いてください。</p><p className="holdout-note">アルバムの写真は削除されません。</p></>}</section>;
 else content=<section className="holdout-panel"><h2>次回のご予約</h2><dl className="holdout-detail"><dt>予約日</dt><dd>{complete?'2026年11月14日（土）':'2026年11月7日（土）'}</dd><dt>変更先の日時</dt><dd>2026年11月14日（土） 14:00〜15:00</dd><dt>ご利用施設</dt><dd>中央スタジオ Aルーム</dd></dl>{!complete&&apply(beta?'11月14日の予約に変更':'2026年11月14日に変更する')}</section>;
 return <div className={'holdout-fixture'+(beta?' holdout-beta':'')}><style>{css}</style><header><span className="holdout-brand">{fixture.task==='switch'?'まいにち定期便':fixture.task==='revisit'?'ひよりフォト':'まちのスタジオ'}</span><a href="#home" className="holdout-home" data-holdout-action="home">マイページへ戻る</a></header><main><p className="holdout-eyebrow">MY PAGE</p><h1>{pageTitle}</h1><div className="holdout-content">{content}</div>{complete&&<p className="holdout-status" role="status" data-holdout-complete="true">{definition.objectiveText}</p>}</main><footer>デモアカウント · この画面のお手続きはサンプルデータにのみ反映されます</footer></div>;
}
