const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const cp=require('node:child_process');
const {PNG}=require('pngjs');
const repo=path.resolve(__dirname,'../../..');
const old=path.join(repo,'reports/attention-repair-2026-11-10/live-r2');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const intersection=(a,b)=>({x:Math.max(a.x,b.x),y:Math.max(a.y,b.y),width:Math.max(0,Math.min(a.x+a.width,b.x+b.width)-Math.max(a.x,b.x)),height:Math.max(0,Math.min(a.y+a.height,b.y+b.height)-Math.max(a.y,b.y))});
const geometry=(rect,clear)=>{const v=intersection(rect,clear);return {rect,intersection:v,visibleAreaRatio:v.width*v.height/(rect.width*rect.height),fullyContained:v.width===rect.width&&v.height===rect.height}};
const pixelEquality=(crop,source,clear)=>{let mismatch=0;for(let y=0;y<crop.height;y++)for(let x=0;x<crop.width;x++)for(let c=0;c<4;c++)if(crop.data[(y*crop.width+x)*4+c]!==source.data[((y+clear.y)*source.width+x+clear.x)*4+c])mismatch++;return {equal:mismatch===0,mismatchedChannels:mismatch,comparedChannels:crop.width*crop.height*4}};
const getPath=(v,p)=>p.reduce((x,k)=>x[k],v);
function stageAudit(s,stage,dir){
 const a=stage.assetFiles.current,bytes=fs.readFileSync(path.join(dir,a.file)),actual=hash(bytes),binding=stage.response.request.imageBindings;
 const bindings=binding.assets.map(x=>({logicalId:x.logicalId,reference:x.reference,imageSha256:x.imageSha256,paths:x.paths,hashMatches:actual===x.imageSha256,pathsResolveToCurrent:x.paths.every(p=>getPath(stage.modelInput,p)==='current')}));
 const inputHash=hash(JSON.stringify({input:stage.modelInput,questions:stage.questions,assets:stage.assetFiles}));
 return {actualAssetSha256:actual,recordedAssetSha256:a.sha256,assetMatches:actual===a.sha256,visionHashMatches:actual===s.vision.imageSha256,memoryHashMatches:stage.modelInput.memoryObservations.every(x=>x.imageSha256===actual),inputSha256:stage.inputSha256,recomputedInputSha256:inputHash,inputHashMatches:inputHash===stage.inputSha256,bindingKind:binding.kind,bindings};
}
const runs=[];
for(const seed of [7001,7002,7003]){
 const pair={seed};
 for(const mode of ['crop','foveated']){
  const dir=path.join(old,`${mode}-seed${seed}`,`${mode}-framed-seed-${seed}`),s=read(path.join(dir,'step-1.json')),r=read(path.join(dir,'result.json'));
  const e5=s.audit.targets.find(t=>t.id==='e5'),clear=s.vision.clearRect;
  const text=s.audit.screen.regions.filter(t=>t.id==='t21'||t.id==='t22').map(t=>({text:t.text,...geometry({x:t.bbox.x0,y:t.bbox.y0,width:t.bbox.x1-t.bbox.x0,height:t.bbox.y1-t.bbox.y0},clear)}));
  pair[mode]={relativeLog:path.relative(repo,path.join(dir,'step-1.json')).replaceAll('\\','/'),vision:s.vision,goal:s.modelInput.goal,endUserGoal:s.attention.modelInput.endUserGoal,attentionGoal:s.attention.modelInput.goal,body:geometry({x:e5.x,y:e5.y,width:e5.width,height:e5.height},clear),badge:geometry(e5.badge,clear),text,actionCriteria:s.questions.nextAction.criteria,gateCandidateIds:s.attention.modelInput.observation.candidateIds,gateInputKeys:Object.keys(s.attention.modelInput),gateObservationKeys:Object.keys(s.attention.modelInput.observation),gateQuestions:s.attention.questions,gateResponse:s.attention.response.answers,gateSelection:s.attention.selection,actionResponse:s.response?.answers??null,actionSelection:s.selection,action:s.action,outcome:s.outcome,runEnd:{termination:r.termination,objectiveSuccess:r.objectiveSuccess,looks:r.looks,uiActions:r.uiActions,apiCalls:r.apiCalls,perceivedDone:r.perceivedDone},gateTransport:stageAudit(s,s.attention,dir),...(s.response?{actionTransport:stageAudit(s,s,dir)}:{})};
 }
 const cropDir=path.dirname(path.join(repo,pair.crop.relativeLog)),fovDir=path.dirname(path.join(repo,pair.foveated.relativeLog));
 const crop=PNG.sync.read(fs.readFileSync(path.join(cropDir,'input-1.png'))),audit=PNG.sync.read(fs.readFileSync(path.join(cropDir,'audit-1.png'))),fov=PNG.sync.read(fs.readFileSync(path.join(fovDir,'input-1.png')));
 pair.pixelChecks={cropDimensions:[crop.width,crop.height],auditDimensions:[audit.width,audit.height],foveatedDimensions:[fov.width,fov.height],cropVsAuditClear:pixelEquality(crop,audit,pair.crop.vision.clearRect),cropVsFoveatedClear:pixelEquality(crop,fov,pair.crop.vision.clearRect),auditAssetSha256:hash(fs.readFileSync(path.join(cropDir,'audit-1.png'))),auditHashMatchesRecorded:hash(fs.readFileSync(path.join(cropDir,'audit-1.png')))===pair.crop.vision.sourceSha256};
 pair.sameGoal=pair.crop.goal===pair.foveated.goal&&pair.crop.endUserGoal===pair.foveated.endUserGoal;
 pair.sameFixation=JSON.stringify(pair.crop.vision.fixation)===JSON.stringify(pair.foveated.vision.fixation);
 pair.sameClearRect=JSON.stringify(pair.crop.vision.clearRect)===JSON.stringify(pair.foveated.vision.clearRect);
 pair.sameClickEligibility=JSON.stringify(pair.crop.vision.visibleTargets)===JSON.stringify(pair.foveated.vision.visibleTargets);
 runs.push(pair);
}
const source={};for(const file of ['jev/virtual-beta/attention.ts','jev/virtual-beta/factors.ts','jev/virtual-beta/vision.ts','runner/virtual-beta-core.ts']){
 const bytes=cp.execFileSync('git',['show',`7f35def:${file}`],{cwd:repo});const lines=bytes.toString('utf8').split('\n');source[file]={sha256:hash(bytes),anchors:lines.flatMap((text,i)=>['function attentionInput','const input=shape','observation:shape','function attentionCurrentView','function eligibleTargets','function transformVision','contains(region,control)','function factorCandidates','function factorModelInput','attentionCurrentViewCandidates(candidates)','attentionInput(wire','next.criteria=Object.fromEntries'].some(k=>text.includes(k))?[{line:i+1,text}]:[])};
}
const report={schemaVersion:1,sourceRevision:cp.execFileSync('git',['rev-parse','7f35def'],{cwd:repo,encoding:'utf8'}).trim(),scope:'Read-only analysis of exactly six saved initial framed steps: crop and foveated seeds 7001-7003. No model calls; no product changes; no DOM/audit content supplied to an actor.',source,runs,facts:[
 'All three crop initial images are 960x620 with viewport offset (160,140), scale (1,1), clear viewport rectangle [160,1120) x [140,760). Decoded pixels exactly equal that audit region; no coordinate-frame mismatch was found.',
 'The notification entry e5 body spans viewport x921..1216 and y540.375..654.171875. Exactly 199/295 of its width (67.457627%) lies inside the clear rectangle. Its badge spans x1156.203125..1212, entirely beyond x1120, so 0% is clear/inside the crop.',
 'The complete notification title and subtitle text rectangles are inside the crop; direct image inspection confirms they are readable. A readable label is therefore not sufficient for click eligibility under the full-body/full-badge rule.',
 'The visible target filter correctly admits only e3, e4 and e6. The cropped e2 badge fragment is visible at the left edge but e2 is also correctly absent. No e5 candidate is offered to the action model.',
 'Crop gate current candidate IDs include e3/e4/e6/done/stuck and four look IDs. Gate receives no typed current non-look action criteria or explicit click eligibility rule. Its only action selection question is continue/inspect, plus conditional gazeTarget; end-user task is identical in both frames.',
 'Crop gate chooses continue with probabilities .64/.69/.67; follow-up current-view action excludes looks and chooses stuck with .66/.73/.64. Both samplers use argmax with no adjustments. These runs terminate STUCK after two API calls, zero looks and zero UI actions.',
 'Foveated initial image has identical sharp-region pixels, clearRect, fixation, source screenshot, admitted click IDs and end-user goal, but includes blurred peripheral canvas. Gates choose inspect with .55/.63/.51, then conditional look_3 with .90/.90/.88. This is descriptive within these saved runs and does not identify the model internal cause.',
 'All six recorded crop calls (3 gate and 3 action) match the file SHA256, assetFiles, vision hash, memory hash and opaque imageBindings hashes/path references; request inputSha256 fingerprints also recompute. These logs attest the recorded client binding; the remote server image decode is not independently observed.'
],hypotheses:[
 {claim:'The gate may treat the readable notification label as immediately actionable despite the missing offered click ID.',status:'Plausible, not demonstrated internal reasoning. Supported by visible label / absent candidate mismatch and gate-action disagreement.'},
 {claim:'Blurred peripheral context may help the foveated gate recognize a boundary and assign value to inspection.',status:'Plausible, not causally identified. The crop/foveated runs differ in full delivered canvas and image geometry; three argmax trials are not a controlled pixel ablation.'},
 {claim:'Generic framing alone should prevent STUCK.',status:'Contradicted by these three framed crop runs; a task-frame change without an explicit current-action contract did not resolve the boundary.'}
],minimalIntervention:{purpose:'Make the gate evaluate the actual next non-look decision that continue will request.',dataSource:'Only the already sanitized offered candidates passed into attention code; never audit targets, DOM text, ROI IDs, hidden body/badge rectangles, or an oracle.',proposal:[
 'Add a bounded currentViewActionContext field containing the exact offered non-look candidate ID, neutral label and canonical action type (click/scroll/back/done/stuck/reread/wait/abandon) from the current candidate set.',
 'Supply the generic rule: only offered click IDs are available; readable text or a partial visible control does not grant a click; constrained click eligibility requires the complete control and its badge inside the clear region. Do not identify which omitted control is useful or why a specific ID is missing.',
 'State that continue requests selection from this exact current non-look repertoire, including supported terminal/uncertainty choices; inspect only changes the view. Do not prescribe inspect, a gaze point, correct coordinates, an action, or a fallback when confidence is low.',
 'Retain all original distributions and selection rules. Test the context as one frozen intervention on matched initial observations before claiming it fixes behavior.'
],notYetEstablished:'No live test was run here; an intervention effect remains unverified.'}};
fs.writeFileSync(path.join(__dirname,'initial-framed-audit.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output:'initial-framed-audit.json',sourceRevision:report.sourceRevision,runs:runs.map(r=>({seed:r.seed,geometry:r.crop.body.visibleAreaRatio,allCropTransportChecks:[r.crop.gateTransport,r.crop.actionTransport].every(t=>t.assetMatches&&t.visionHashMatches&&t.memoryHashMatches&&t.inputHashMatches&&t.bindings.every(b=>b.hashMatches&&b.pathsResolveToCurrent)),pixelChecks:r.pixelChecks})),facts:report.facts},null,2));
