/** Offline prior-cohort audit. No inference, network, dotenv, or actor writes. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath, pathToFileURL} from 'node:url';
const outputDir=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(outputDir,'../../..');
const relative=file=>path.relative(root,file).replaceAll('\\','/');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const read=file=>fs.readFileSync(path.resolve(root,file));
const json=file=>JSON.parse(read(file).toString('utf8'));
const baselineRevision='5eb463e5cddbd8ddc17c833c8b7df0fd05259d08';
const phasePath='reports/attention-reselection-2026-11-09/live-r1/phase.json';
const phase=json(phasePath),base=path.dirname(path.join(root,phasePath));
assert.equal(phase.status,'COMPLETED');assert.equal(phase.mock,false);
for(const [file,hash]of Object.entries(phase.inputHashes))assert.equal(sha(read(file)),hash,file);
const {verifyJevImageBindings}=await import(pathToFileURL(path.join(root,'runner/jev-image-references.ts')).href);
const sourceReferences=[
 ['jev/virtual-beta/attention.ts',[3,8,16,48,56]],
 ['runner/virtual-beta-core.ts',[169,172,174,177,202,208,217,219,226,292,299,305,309,312]],
 ['jev/virtual-beta/factors.ts',[35,40,50,84]],
 ['jev/virtual-beta/selection.ts',[27,81,90,116]],
 ['jev/virtual-beta/user-state.ts',[22,25,26,27]],
 ['runner/virtual-beta-evaluator.ts',[15,18,19,21]],
 ['runner/jev-image-references.ts',[47,85,101,113,114]],
 ['runner/virtual-beta-action-instructions.ts',[12,13]],
].map(([file,lines])=>{
 const bytes=execFileSync('git',['show',baselineRevision+':'+file],{cwd:root,maxBuffer:16*1024*1024});
 return {file,revision:baselineRevision,gitBlobSha256:sha(bytes),lines:lines.map(line=>({line,text:bytes.toString('utf8').split(/\r?\n/)[line-1]}))};
});
const audit={schemaVersion:1,kind:'offline-preexperiment-diagnostics',baselineRevision,
 phase:{path:phasePath,sha256:sha(read(phasePath)),recordedActor:phase.source,inputHashes:phase.inputHashes},
 sourceReferences,bindingVerifier:{path:'runner/jev-image-references.ts',fileSha256:sha(read('runner/jev-image-references.ts'))},
 counts:{runs:0,requests:0,attentionDecisions:0,attentionModelContinue:0,attentionSelectedContinue:0,lookMassStrictlyGreater:0,lookMassConceptualTies:0,bindingStages:0,assetOccurrencesRehashed:0,memoryEntriesMatched:0,attentionMemoryEntriesMatched:0,selectionModelDifferences:0,adjustments:0,requestFailures:0,initialOrdinaryLooks:0,continueThenOrdinaryLooks:0,notificationVisits:0,notificationVisitsON:0,notificationVisitsOFF:0,notificationVisitsWithoutClickCandidates:0,notificationRepeatedTitleInMemory:0,notificationRepeatedHashInMemory:0,notificationRepeatedTitleInMemoryON:0,notificationRepeatedHashInMemoryON:0,allRepeatedTitleInMemory:0,allRepeatedHashInMemory:0},
 results:[],attention:[],continueThenOrdinaryLooks:[],memoryCorrespondence:[],assetOccurrences:[],notificationVisits:[]};
for(const batch of [...phase.batches].sort((a,b)=>a.id.localeCompare(b.id))){
 const batchDir=path.join(base,batch.id);
 for(const run of fs.readdirSync(batchDir).sort()){
  const resultFile=path.join(batchDir,run,'result.json');if(!fs.existsSync(resultFile))continue;
  const bytes=fs.readFileSync(resultFile),r=JSON.parse(bytes.toString('utf8')),on=r.config.attention?.enabled===true;
  assert.deepEqual(r.code,phase.source);assert.equal(r.validForComparison,true);
  audit.counts.runs++;
  const titleByObservation=new Map(r.steps.map(s=>[s.observationId,s.audit.screen.title]));
  const resultRecord={runId:r.runId,path:relative(resultFile),sha256:sha(bytes),attentionEnabled:on,vision:r.config.vision.mode,termination:r.termination,apiCalls:r.apiCalls,decisions:r.decisions,looks:r.looks,uiActions:r.uiActions,objectiveSuccess:r.objectiveSuccess,perceivedDone:r.perceivedDone,paths:r.steps.map(s=>({decision:s.number,observationId:s.observationId,titleAuditOnly:s.audit.screen.title,action:s.action,outcome:s.outcome,currentImageSha256:s.vision.imageSha256})),repeatedTitleInMemoryDecisions:[],repeatedHashInMemoryDecisions:[]};
  audit.results.push(resultRecord);
  const first=r.steps[0];if(first.action?.type==='look'&&first.response)audit.counts.initialOrdinaryLooks++;
  for(const s of r.steps){
   const current=s.modelInput.observation,mem=s.modelInput.userState.memory;
   const prior=mem.filter(m=>m.observationId!==s.observationId);
   const repeatedTitle=prior.some(m=>titleByObservation.get(m.observationId)===s.audit.screen.title);
   const repeatedHash=prior.some(m=>m.imageSha256===s.vision.imageSha256);
   if(repeatedTitle){audit.counts.allRepeatedTitleInMemory++;resultRecord.repeatedTitleInMemoryDecisions.push(s.number);}
   if(repeatedHash){audit.counts.allRepeatedHashInMemory++;resultRecord.repeatedHashInMemoryDecisions.push(s.number);}
   if(s.audit.screen.title==='通知設定'){
    audit.counts.notificationVisits++;audit.counts[on?'notificationVisitsON':'notificationVisitsOFF']++;
    const noClicks=!Object.keys(s.questions.nextAction.criteria).some(k=>/^e\d+$/.test(k));
    if(noClicks)audit.counts.notificationVisitsWithoutClickCandidates++;
    if(repeatedTitle){audit.counts.notificationRepeatedTitleInMemory++;if(on)audit.counts.notificationRepeatedTitleInMemoryON++;}
    if(repeatedHash){audit.counts.notificationRepeatedHashInMemory++;if(on)audit.counts.notificationRepeatedHashInMemoryON++;}
    audit.notificationVisits.push({runId:r.runId,decision:s.number,attentionEnabled:on,candidateIds:current.candidateIds,noClickCandidates:noClicks,attention:s.attention?.selection?.selected??null,attentionReason:s.attention?.response?.answers?.decisionBasis?.choice??null,action:s.action,repeatedTitleAuditOnly:repeatedTitle,repeatedHash,priorMemoryObservationIds:prior.map(m=>m.observationId)});
   }
   for(const [stageName,stage]of [['ordinary',s],['attention',s.attention]]){
    if(!stage?.response)continue;
    const c=audit.counts;c.requests++;c.requestFailures+=stage.response.request.failures.length;
    verifyJevImageBindings(stage.modelInput,stage.questions,stage.assetFiles,stage.response.request.imageBindings);c.bindingStages++;
    if(stage.selection.modelChoice!==stage.selection.selected)c.selectionModelDifferences++;
    c.adjustments+=stage.selection.adjustments.length;
    for(const [id,asset]of Object.entries(stage.assetFiles)){
     const file=path.join(path.dirname(resultFile),asset.file),hash=sha(fs.readFileSync(file));
     assert.equal(hash,asset.sha256);assert.equal(stage.response.request.imageBindings.assets.find(a=>a.logicalId===id)?.imageSha256,hash);
     c.assetOccurrencesRehashed++;
     audit.assetOccurrences.push({runId:r.runId,decision:s.number,stage:stageName,logicalId:id,path:relative(file),sha256:hash});
    }
    for(const memory of stage.modelInput.userState.memory){
     const reference=stage.modelInput.memoryObservations.find(ref=>ref.observationId===memory.observationId);
     assert(reference);assert.equal(reference.imageSha256,memory.imageSha256);assert.equal(stage.assetFiles[reference.image].sha256,memory.imageSha256);
     c.memoryEntriesMatched++;if(stageName==='attention')c.attentionMemoryEntriesMatched++;
     audit.memoryCorrespondence.push({runId:r.runId,decision:s.number,stage:stageName,observationId:memory.observationId,currentObservation:memory.observationId===s.observationId,image:reference.image,imageSha256:memory.imageSha256,assetFile:stage.assetFiles[reference.image].file,incomingAction:memory.action??null,incomingOutcome:memory.outcome??null,titleAuditOnly:titleByObservation.get(memory.observationId)});
    }
    if(stageName==='attention'){
     c.attentionDecisions++;if(stage.selection.modelChoice==='continue')c.attentionModelContinue++;if(stage.selection.selected==='continue')c.attentionSelectedContinue++;
     const p=stage.selection.normalized,lookMass=Object.entries(p).filter(([key])=>key.startsWith('look_')).reduce((n,[,v])=>n+v,0),delta=lookMass-p.continue;
     const tie=Math.abs(delta)<1e-12,strict=delta>1e-12;
     if(strict)c.lookMassStrictlyGreater++;if(tie)c.lookMassConceptualTies++;
     audit.attention.push({runId:r.runId,decision:s.number,modelChoice:stage.selection.modelChoice,selected:stage.selection.selected,normalized:p,continueMass:p.continue,combinedLookMass:lookMass,lookMassStrictlyGreater:strict,conceptualTie:tie,ordinaryAction:s.action,reasonSelfReport:stage.response.answers.decisionBasis.choice});
     if(stage.selection.selected==='continue'&&s.action?.type==='look'&&s.response){
      c.continueThenOrdinaryLooks++;
      audit.continueThenOrdinaryLooks.push({runId:r.runId,decision:s.number,attentionSelected:stage.selection.selected,attentionNormalized:p,ordinaryModelChoice:s.selection.modelChoice,ordinarySelected:s.selection.selected,ordinaryAction:s.action,ordinaryNormalized:s.selection.normalized,stepPath:relative(path.join(path.dirname(resultFile),'step-'+s.number+'.json'))});
     }
    }
   }
  }
 }
}
assert.equal(audit.counts.runs,12);assert.equal(audit.counts.requests,114);assert.equal(audit.counts.attentionDecisions,36);assert.equal(audit.counts.attentionModelContinue,36);assert.equal(audit.counts.attentionSelectedContinue,36);assert.equal(audit.counts.lookMassStrictlyGreater,4);assert.equal(audit.counts.lookMassConceptualTies,1);assert.equal(audit.counts.bindingStages,114);assert.equal(audit.counts.assetOccurrencesRehashed,260);assert.equal(audit.counts.continueThenOrdinaryLooks,6);assert.equal(audit.counts.selectionModelDifferences,0);assert.equal(audit.counts.adjustments,0);assert.equal(audit.counts.requestFailures,0);
const evidence=JSON.stringify(audit,null,2)+'\n';
if(process.argv.includes('--write')){
 const evidenceFile=path.join(outputDir,'evidence.json');assert(!fs.existsSync(evidenceFile),'Refuse overwrite; use --verify for reproduction');
 fs.writeFileSync(evidenceFile,evidence,{flag:'wx'});
}else{
 assert(process.argv.includes('--verify'),'Run --write once or --verify against existing evidence');
 assert.equal(fs.readFileSync(path.join(outputDir,'evidence.json'),'utf8'),evidence,'Offline evidence differs from saved audit');
}
console.log(JSON.stringify({verified:true,phaseSha256:audit.phase.sha256,evidenceSha256:sha(evidence),counts:audit.counts},null,2));
