# Independent preexperiment attention diagnostics

2026-11-10 JST. This report audits the previous live cohort only. No new inference, network requests, .env access, actor modifications, or prior-artifact modifications were performed by this audit. Files created by this investigator are confined to this diagnostics directory.

## Finding and priority

The strongest demonstrated design issue is overlap between attention alternatives. Old continue means defer to the ordinary action decision, which still offers all four look actions. It does not commit the next executed action to maintaining fixation. Six live ON decisions demonstrate continue followed immediately by ordinary look_3. Consequently, 36 attention continue choices are not 36 independent decisions to keep fixation. This structural issue is established; whether it psychologically caused every model choice is not established.

Flat argmax also divides look probability among destinations. It is an arithmetic contributor in four of 36 saved distributions, not a sufficient explanation of the whole result. A newly asked binary question may yield different probabilities; these saved probabilities do not establish its effect.

Action/image memory was delivered and can expose previously visited views. No missing-image or missing-action mechanism was found. The memory is bounded raw observation/event evidence, not a verified goal-progress model. Provider-internal use of images or memory is not observable in these artifacts.

No client-side transport, filtering, selection, or execution mismatch was found in the inspected cohort. These findings do not establish a successful repair; the new comparison has not been run by this investigator.

## Frozen evidence and method

Inspected source baseline: Git revision 5eb463e5cddbd8ddc17c833c8b7df0fd05259d08. Source references below refer to that revision even if implementation files subsequently change. Exact Git blob SHA256 values and line text are retained in evidence.json.

Prior phase: reports/attention-reselection-2026-11-09/live-r1/phase.json.

Phase SHA256: 9827637a7e9c73e884da2824cdfe60f60eea6666afebfbb92689dff9c2425545.

Its recorded actor is revision 9e403ae9ce1f1e29840481a06f1f2504b7cf3058 with sourceHash 3decbfde991586a623258781f440024255dda55c125ca293c1c950f2a9b6d46a. The phase records execution-time source, while 5eb463e is the independently inspected committed implementation. Do not conflate these identifiers.

The offline script verifies all prior phase input hashes, reads 12 raw result.json files, asserts each result's code identity equals the recorded phase source, verifies opaque image-reference paths with the production pure verifier, and independently hashes each attachment against its PNG bytes. It records individual image/action-memory correspondences and complete action traces. It does not call the evaluator or its inference transport.

The 260 attachment checks are stage occurrences, not 260 unique image files. Memory-image deduplication is intentional: a historical observation with current-image-identical bytes can reference the current attachment.

## Exact counts

- 12 original runs, 114 completed response stages, 36 attention decisions.
- 36 attention modelChoice values and 36 attention selected values are continue.
- 0 modelChoice/selected differences, 0 filtering adjustments, and 0 recorded request failures across all response stages.
- All 114 opaque image bindings pass verifyJevImageBindings; 260 attachment occurrences match actual PNG bytes and binding hashes.
- 288 memory entry occurrences match attached image references; 90 are in attention requests. No memory entry is unmatched.
- All 12 first ordinary decisions select look_3. Six belong to attention-ON runs and occur after attention continue.
- OFF: six runs each terminate UI_ACTION_LIMIT after 7 decisions, 7 requests, 6 UI actions and 1 look.
- ON: six runs each terminate API_LIMIT after 6 decisions, 12 requests, 5 UI actions and 1 look.
- All 12 report objectiveSuccess=false and perceivedDone=false. This is a bounded fixture result, not evidence of human validity.

## Attention fragmentation, precisely

Continue normalized mass ranges from 0.47 to 0.83. Individual look masses never exceed continue. Summing look_0 through look_3 strictly exceeds continue in these four decisions:

- crop-attention-seed-5001 decision5: continue .49, combined looks .51.
- crop-attention-seed-5002 decision5: continue .47, combined looks .53.
- crop-attention-seed-5003 decision3: continue .48, combined looks .52.
- crop-attention-seed-5003 decision5: continue .47, combined looks .53.

crop-attention-seed-5002 decision3 is a conceptual .50/.50 tie; floating-point roundoff is treated with tolerance 1e-12. The remaining 31 distributions strictly prefer continue over combined looks. Thus grouping does not reverse 32 of 36 decisions under the original continue-favouring tie policy. Only four strict reversals are supported by arithmetic. A new binary prompt is a fresh empirical intervention, not equivalent to summing saved probabilities.

Source: jev/virtual-beta/attention.ts lines8–17 generates continue plus copied look candidates; jev/virtual-beta/selection.ts line27 chooses flat argmax. See evidence.json attention entries for every normalized distribution.

## Six observed continue-to-look instances

Each following run executes attention continue at decision1, then ordinary look_3 at viewport point (960,675):

- crop-attention-seed-5001.
- foveated-attention-seed-5001.
- crop-attention-seed-5002.
- foveated-attention-seed-5002.
- crop-attention-seed-5003.
- foveated-attention-seed-5003.

These are descriptive existing outputs, not prescribed coordinates for a new actor. The ordinary distributions and precise raw step paths are in evidence.json continueThenOrdinaryLooks.

Source: attention.ts line3 explicitly says continue requests the normal action decision; virtual-beta-core.ts line202 builds ordinary criteria from all candidates, lines219–227 route continue to normal inference, and lines292–305 infer/select/execute that ordinary action. factors.ts adds the same four look choices. This proves overlap in the implemented action sets. It does not prove the model's private reason for preferring continue.

Representative raw proof: prior crop-attention-seed-5001/step-1.json line1395 records attention choice continue; line1497 records ordinary choice look_3; line1600 records ordinary selected look_3; line1616 records FIXATION_MOVED.

## Notification view, available stop actions, and memory recurrence

The original 12 runs contain 30 notification-setting visits: 12 ON and 18 OFF. Every one offers back, done, stuck, look_0, look_1, look_2, look_3 and no numbered click candidate. Every one then executes back. ON attention labels all 12 such visits uncertainty while still choosing continue. This self-report is not internal reasoning evidence.

Thus terminal done/stuck alternatives and alternative views remain available even when the transformed notification image has no eligible click control. The recorded outcome is repeated back, not an unavailable stop action or an exhausted-look filter.

Across these 30 visits, the bounded memory contains a previous visit to the same notification-page title in 18 cases (ON6/OFF12). In eight cases the retained notification image is byte-identical to the current image (ON2/OFF6). Audit titles classify semantic visits only for this investigator; those titles are not added to model input and are not treated as actor-visible evidence. Small image differences mean semantic route recurrence and exact image-hash recurrence must remain distinct.

Across all 78 executed decisions, 54 have a prior same-title observation in memory and 20 have an exact current-image hash already retained. Counts include decision2 on the home title, whose image can differ after initial gaze movement. They are evidence availability counts, not proof of model recognition.

Memory capacity3 includes the current observation, so at most two previous observations are retained. Example crop-attention-seed-5001 decision5:

- o3: image A (749df656a367614f61b4f6af2e30641a82e9f10ee79dcae902378062fdb9d17b), incoming click e5, performed.
- o4: image B (4274d44ba2fa8bb0673e3307ab41c6470af18f2da868cae54a0647bdba5c2c87), incoming back, performed.
- o5: image A, incoming click e5, performed.

o3 and o5 reference current; o4 references memory_1 (input-4.png). Their chronology exposes an A→B→A recurrence. This exact byte recurrence example must not be generalized to every run. Incoming events attach to the newly observed image, rather than denoting an action proposed from that image. performed means a UI action was executed, not that the entire goal progressed.

Source: user-state.ts lines22–29 constructs bounded memory with incoming event; attention.ts lines48–60 preserves action/outcome and memory image references; virtual-beta-core.ts lines172–183 constructs and attaches memory; lines309–312 records execution and the pending incoming event. Representative raw memory: crop-attention-seed-5001/step-5.json lines966–1029.

## Transport and execution limits

Pure binding verification and all local PNG hashes agree for all114 response stages. The evaluator rewrites logical IDs into opaque request UUIDs and records the binding: virtual-beta-evaluator.ts lines18–21; jev-image-references.ts lines101–118. This verifies the client-side image map, not whether the provider internally attended to or understood each image.

The sampler selections match reported model choices and executed actions. Since this live cohort contains no attention-selected look, its attention-look branch cannot be empirically validated from these runs alone. Code routes such selections into the existing candidates/action executor (virtual-beta-core.ts lines226 and305–312); separate runtime tests are distinct evidence and were not newly run by this audit.

## Preexperiment comparison interpretation

Parent's proposed finite comparison has four arms: OFF, legacy attention, exclusive flat attention, exclusive hierarchical attention; two vision modes and three assigned seeds (24 runs, at most288 requests). This is planned work and is not included in the old evidence counts.

The exclusive flat versus exclusive hierarchical contrast isolates grouping within a mutually exclusive action contract. Legacy versus exclusive flat examines the contract change; OFF versus legacy also includes the extra inference cost. Report actual executed looks, ordinary looks after continue, fresh transformed observations, repeated UI operations, and API use over a shared decision horizon. Equal API budgets alone shorten ON opportunity in the old cohort. External model randomness remains uncontrolled by local selection seeds.

Use fresh normal-runner observations with unchanged task/persona/UI for the mechanism comparison. Preserve bounded original memory, existing general viewport points, ordinary image transformation and UI execution. Do not add answer coordinates, hidden DOM, oracle-derived hints, forced exploration, or revisit bans. No memory ablation is proposed for this experiment. A better attention mechanism still requires an empirical movement result; a changed gate choice alone is insufficient.

## Reproduction

From the repository root, with existing node_modules and prior raw artifacts available:

    node --import tsx reports/attention-repair-2026-11-10/diagnostics/audit-prior.mjs --verify

The script recomputes evidence deterministically and compares the complete bytes with evidence.json; any changed source baseline, phase input, raw result, attachment, binding, or correspondence fails verification or produces a mismatch. The source baseline is read with git show at the fixed revision, allowing actor work to proceed separately. The pure binding verifier's current file hash is included, so changes to it also require explicit evidence regeneration. The initial --write mode refuses to overwrite existing evidence.

Files in this directory: audit-prior.mjs (offline reproduction), evidence.json (full source/raw hash inventory and per-decision checks), report.md (this interpretation), manifest.json (SHA256 inventory of these deliverables). No prior evidence was modified.

## Exact raw result SHA256 inventory

- crop-attention-seed-5001: 244c23f0f4dd7d61c9ac6b84ffbbaef4f23b5632ff8539809d1c5cbb9856e3fa
- crop-current-seed-5001: d374ce597db8f654787142b8edd721e91c2e5315bfd508575a6dc7dfb3c64a96
- foveated-attention-seed-5001: 75b9bbd64ebc6749d3041bdcb0f9bb4943d56f94596abadac9c0bfa451a99565
- foveated-current-seed-5001: 63801a84c33d33bf1e923fe7515e05929cf24dcdeba5bd4d661e162dcee3e55c
- crop-attention-seed-5002: 67a0c55ba5229d2556be314925e99900df61463cfbf8dbd2ec543d2c061ca74c
- crop-current-seed-5002: 91a4795b59307e7cac8bb57f834e4a2a83236c9fec6f5db9b9bccb8af5c6d530
- foveated-attention-seed-5002: 76f72e245b10129a20d1ed05d7702acbcdaf934244075e7985a7baa64e9db403
- foveated-current-seed-5002: 62fed3fd4c77e7be0c8c8148b352bfa3f345408346cfb43ffb037ce1a8c27bda
- crop-attention-seed-5003: c05c1c5e11b9df0dac423c042c38a63742c12275a3d793695c597ac2eec9a696
- crop-current-seed-5003: 31dc8fb310d264293789400f7e9362cc63b7268f8d6314e2088738d5432b37f7
- foveated-attention-seed-5003: 1d8a1ba625381879007dfd85f4bb5734e49a01e9c3dcb78ca7cb75ef5e5dc26f
- foveated-current-seed-5003: 99c0cf0929ca10ea80758bb0daa836ec13259ee559bf65ea83a2d4318192f1b6

## Exact inspected Git source SHA256 inventory

- jev/virtual-beta/attention.ts: bbff65b1df0993cce5f827e4e95c33204196394b424145261221b69e6d8df911
- runner/virtual-beta-core.ts: 40284ff77cef39f2e909c7319b1f547244bf3267c685eac7b9038b280dea9c87
- jev/virtual-beta/factors.ts: 27420cc4fe12523b7dbc98b275602fc90d25cb3cb803b1abfdd32de697068266
- jev/virtual-beta/selection.ts: 6f5bf252dc94543f92d426af99c59c7c25c4dda88efeace3d2f4e1aeeb73d012
- jev/virtual-beta/user-state.ts: 9fca703785d937d9e86f991a5cdd7d3b5540e0fc40ef45c9b3e0085c306b232d
- runner/virtual-beta-evaluator.ts: c9fb7f59ca0991a2627550a059aff2007e01bc7bae7fab233af8c3e64438524d
- runner/jev-image-references.ts: ab9085b73ccc228fa651584b6a73650fa8277d3d9a178b51c1b47a42721c2387
- runner/virtual-beta-action-instructions.ts: bc531a578cfe36e4ba2cd7e7e5844bd5a3461c91008d586b041a7c543d0583cf
